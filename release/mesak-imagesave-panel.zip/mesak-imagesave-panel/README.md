# Image Save Panel Plugin for Grafana

This plugin is a panel plugin for Grafana that allows you to save image to grafana.

## Screenshots

![Screenshot](https://raw.githubusercontent.com/mesak/grafana-imagesave-panel/main/src/img/screenshot.jpg)