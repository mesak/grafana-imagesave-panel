# Image Save Panel Plugin for Grafana

This plugin is a panel plugin for Grafana that allows you to save image to grafana.

[screenshot.jpg]

## Screenshots

![Screenshot](https://raw.githubusercontent.com/mesak/grafana-imagesave-panel/main/src/screenshot.jpg)